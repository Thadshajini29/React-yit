import React from 'react'
import './Header.css'
export default function Header() {
  return (
    <div>
        <div className="header">
            <h1>School System</h1>
        </div>
    </div>
  )
}
