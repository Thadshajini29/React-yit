import React from 'react'
import './Content.css'
import Student from '../pages/Student'
import Studentdetail from '../pages/Studentdetail'
export default function Content() {
  return (
    <div>
        <div className="content">
            {/* <Student/> */}
            {/* <Studentdetail/> */}
        </div>
    </div>
  )
}
